package com.example.simbirsoftsummerworkshop

import android.app.Application

class App : Application(){
}