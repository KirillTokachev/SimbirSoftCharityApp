package com.example.simbirsoftsummerworkshop.view.fragments


import androidx.core.net.toUri
import androidx.fragment.app.commit
import androidx.navigation.fragment.findNavController
import androidx.navigation.navDeepLink
import com.example.simbirsoftsummerworkshop.R
import com.example.simbirsoftsummerworkshop.databinding.FragmentSplashBinding

private const val TIME_SLEEP: Long = 1700

class SplashFragment : BaseFragment<FragmentSplashBinding>() {

    override fun getViewBinding() = FragmentSplashBinding.inflate(layoutInflater)

    private val background = object : Thread() {
        override fun run() {
            try {
                sleep(TIME_SLEEP)
                findNavController().navigate(R.id.action_splashFragment_to_mainFragment)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun setUpViews() {
        background.start()
    }

}
