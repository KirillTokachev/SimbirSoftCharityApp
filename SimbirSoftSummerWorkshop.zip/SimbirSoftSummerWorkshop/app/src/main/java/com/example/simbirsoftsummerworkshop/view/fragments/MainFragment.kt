package com.example.simbirsoftsummerworkshop.view.fragments


import android.util.Log
import android.view.View
import androidx.core.net.toUri
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.ui.setupWithNavController
import com.example.simbirsoftsummerworkshop.MainActivity
import com.example.simbirsoftsummerworkshop.R
import com.example.simbirsoftsummerworkshop.databinding.FragmentMainBinding
import kotlinx.android.synthetic.main.fragment_main.*

class MainFragment : BaseFragment<FragmentMainBinding>() {
    override fun getViewBinding() = FragmentMainBinding.inflate(layoutInflater)

    override fun setUpViews() {
        setupNav()
    }

    private fun setupNav() {

        val nestedNavHostFragment = childFragmentManager.findFragmentById(R.id.second_container_view) as? NavHostFragment
        val navController = nestedNavHostFragment?.navController

        if (navController != null) {
            bottom_navigation.setupWithNavController(navController)
        }

        bottom_navigation.apply {
            background = null
            menu.getItem(2).isEnabled = false
            selectedItemId = R.id.bottom_menu_help
            setOnItemSelectedListener {
                when (it.itemId) {
                    R.id.bottom_menu_profile -> {
                        navController?.navigate(R.id.action_helpFragment_to_profileFragment)
                        return@setOnItemSelectedListener true
                    }
                    else -> return@setOnItemSelectedListener false
                }
            }
        }

        fb_help.setOnClickListener {
            navController?.navigate(R.id.action_profileFragment_to_helpFragment)
            bottom_navigation.selectedItemId = R.id.bottom_menu_help
            Log.d("dist", "${navController?.currentDestination}")
        }

        navController?.addOnDestinationChangedListener { controller, destination, arguments ->
            when (destination.id) {
                R.id.mainFragment -> showBottomNav()
                R.id.cameraFragment -> hideBottomNav()
            }
        }
    }

    private fun showBottomNav() {
        bottom_navigation.visibility = View.VISIBLE
    }

    private fun hideBottomNav() {
        bottom_navigation.visibility = View.GONE
    }

    companion object {
        @JvmStatic
        fun newInstance() = MainFragment()
    }

}