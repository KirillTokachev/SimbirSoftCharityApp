package com.example.simbirsoftsummerworkshop.data

import android.graphics.Bitmap

data class Help(
    val title: String,
    val icon: Bitmap
)
