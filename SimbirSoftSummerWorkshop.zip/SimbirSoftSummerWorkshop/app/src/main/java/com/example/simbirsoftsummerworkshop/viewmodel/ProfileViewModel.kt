package com.example.simbirsoftsummerworkshop.viewmodel

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.simbirsoftsummerworkshop.data.Datas

class ProfileViewModel : ViewModel() {
    private var photoUri = MutableLiveData<Uri>()

    val photoPath: LiveData<Uri> = photoUri

    private lateinit var profileData: Datas

    fun savePhoto(uri: Uri) {
        photoUri.value = uri
    }
    
}